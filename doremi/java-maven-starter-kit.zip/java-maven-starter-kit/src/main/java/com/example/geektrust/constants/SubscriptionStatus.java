package com.example.geektrust.constants;

public enum SubscriptionStatus {

    ACTIVATED,
    UNACTIVATED,
    INVALID_DATE;

}
