package com.example.geektrust.constants;

public final class Constants {
    public Constants() {

    }

    public static Integer INITIAL_NO_OF_USERS = 0;

    public static Integer FIRST_USER = 1;

    public static Integer INITIAL_AMOUNT = 0;

    public static Integer MINUS_TEN_DAYS = 10;

}
